const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const XAI_API_KEY = process.env.XAI_API_KEY;
const XAI_API_URL = 'https://api.x.ai/v1/chat/completions'; // Verify with xAI API docs

app.post('/api/ai/suggestions', async (req, res) => {
    try {
        const { resume, jobDescription, prompt } = req.body;
        const response = await axios.post(
            XAI_API_URL,
            {
                model: 'grok-3', // Adjust if xAI specifies a different model
                messages: [
                    { role: 'system', content: prompt },
                    { role: 'user', content: `Resume: ${resume}\nJob Description: ${jobDescription}` }
                ],
                max_tokens: 500,
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${XAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        res.json({ suggestions: response.data.choices[0].message.content });
    } catch (error) {
        console.error('AI Suggestions Error:', error.message);
        res.status(500).json({ error: 'Failed to fetch AI suggestions' });
    }
});

app.post('/api/ai/chat', async (req, res) => {
    try {
        const { message, resume, prompt } = req.body;
        const response = await axios.post(
            XAI_API_URL,
            {
                model: 'grok-3',
                messages: [
                    { role: 'system', content: prompt },
                    { role: 'user', content: `Resume: ${resume}\nUser Query: ${message}` }
                ],
                max_tokens: 500,
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${XAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        res.json({ response: response.data.choices[0].message.content });
    } catch (error) {
        console.error('AI Chat Error:', error.message);
        res.status(500).json({ error: 'Failed to fetch AI response' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));